//
//  NMECollectPointGuideView.m
//  pageControllDemo
//
//  Created by qfpayJakeMeng on 16/5/30.
//  Copyright © 2016年 mountainKing. All rights reserved.
//

#import "NMECollectPointGuideView.h"
#import "NMEPointIntroCollectionViewCell.h"

@interface NMECollectPointGuideView()
<
UICollectionViewDelegate,
UICollectionViewDataSource
>
{
    __weak IBOutlet UICollectionView *_collectionView;
    __weak IBOutlet UIPageControl *_pageControl;
    UICollectionViewFlowLayout *_layout;
    NSArray *arrImages;
}

@end

@implementation NMECollectPointGuideView

- (void)awakeFromNib {
    [self setupCollectionView];
    [self setupPageControl];
}

- (NSArray *)arrImages {
    NSArray *images = @[@"img_guide_1",@"img_guide_2",@"img_guide_3",@"img_guide_4",@"img_guide_5",@"img_guide_6"];
    return images;
}

- (void)setupCollectionView {
    _collectionView.delegate = self;
    _collectionView.dataSource = self;
    [_collectionView registerNib:[UINib nibWithNibName:@"NMEPointIntroCollectionViewCell" bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:@"NMEPointIntroCollectionViewCell"];
    _layout = [[UICollectionViewFlowLayout alloc] init];
    _collectionView.collectionViewLayout = _layout;
    _layout.itemSize = CGSizeMake(CGRectGetWidth(_collectionView.frame), CGRectGetHeight(_collectionView.frame));
    _layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    [_collectionView reloadData];
}

- (void)setupPageControl {
    _pageControl.pageIndicatorTintColor = [UIColor blueColor];
    _pageControl.currentPageIndicatorTintColor = [UIColor whiteColor];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    NMEPointIntroCollectionViewCell *cell = (NMEPointIntroCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"NMEPointIntroCollectionViewCell" forIndexPath:indexPath];
    if (!cell) {
        [_collectionView registerNib:[UINib nibWithNibName:@"NMEPointIntroCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"NMEPointIntroCollectionViewCell"];
        cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"NMEPointIntroCollectionViewCell" forIndexPath:indexPath];
    }
    cell.inrtoImageView.image = [UIImage imageNamed:self.arrImages[indexPath.row]];
    
    return cell;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return 6;
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

//- (id)initWithFrame:(CGRect)frame {
//    self = [super initWithFrame:frame];
//    self.frame = frame;
//    
//    
//    
//    return self;
//}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
