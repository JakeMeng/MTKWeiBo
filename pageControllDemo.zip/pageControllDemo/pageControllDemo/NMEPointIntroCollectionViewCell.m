//
//  NMEPointIntroCollectionViewCell.m
//  pageControllDemo
//
//  Created by qfpayJakeMeng on 16/5/30.
//  Copyright © 2016年 mountainKing. All rights reserved.
//

#import "NMEPointIntroCollectionViewCell.h"

@implementation NMEPointIntroCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
